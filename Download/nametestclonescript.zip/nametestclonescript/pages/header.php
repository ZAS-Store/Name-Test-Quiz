<body>
<header class="navbar navbar-static-top top-bar" id="top" role="banner">
<div class="container">
<div class="navbar-header">
<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#bs-navbar" aria-controls="bs-navbar" aria-expanded="false">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand web-logo" href=index.php style="padding: 10px"><img src="http://www.zupimages.net/up/16/17/kbmv.png" style="padding-right: 5px"/>NametestsCloneScript</a>
</div>
<nav id="bs-navbar" class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
<ul class="nav navbar-nav">
<li>
<a href=index.html class="menu-item">Home</a>
</li>
<li>
<a href=# class="menu-item">Contact Skype : lucia.itaaliana</a>
</li>
</ul>
</nav>
</div>

