 <center><center><?php echo $CONF['ads_300'];?></center>
 <div class="footer">
    <div class="container">
      <p class="muted">
        <a href=index.html>Home</a>
        <span>&middot;</span>
        <a href=delete.html target="_blank">Delete App</a>
        <span>&middot;</span>
        <a href=support.html target="_blank">Contact Us</a>
        <span>&middot;</span>
        <a href=privacy.html target="_blank">Privacy</a>
      </p>
      <p class="muted">
        Disclaimer: All content is provided for fun and entertainment purposes only.
      </p>
    </div><script id="_waugko">var _wau = _wau || []; _wau.push(["small", "rkp5ohvf58hb", "gko"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="http://widgets.amung.us/small.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>