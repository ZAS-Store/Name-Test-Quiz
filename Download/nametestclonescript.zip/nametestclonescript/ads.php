<?php
define('TEST_ZDK', true);
require_once './global.php';

include './templates/ads.html';
?>